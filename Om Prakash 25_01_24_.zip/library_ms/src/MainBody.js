
import React from "react";
import "./MainBody.css"; 

const MainBody = () => {
  return (
    <div className="main-body">
      <div className="row">
   
        <div className="col-md-6 left-part">
          <h1>Good books don't give up all their secrets at once</h1>
          <br></br>
          <h4>A small river named Duden Flows by their place and supplies it with the necessary regelialia. </h4>
          <button className="oval-button">Services</button>
        </div>

        <div className="container1">
        
        </div>
        
      </div>
    </div>
  );
};

export default MainBody;
