// App.js

import React from 'react';
import Header from './Header'
import './App.css'
import Navbar from './Navbar';
import MainBody from './MainBody';
import BottomPart from './BottomPart';


const App = () => {
  return (
    <div>
     <Header/>
      {/* Other components and content */}
      <Navbar/>
      <MainBody/>
      <BottomPart/>
      
    </div>
  );
}

export default App;
